﻿************
Framework
************
core: 
====================
.. automodule:: neurolab.core
    :members: