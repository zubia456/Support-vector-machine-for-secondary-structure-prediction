﻿******************************
Single Layer Perceptron (newp)
******************************

Use  :py:func:`neurolab.net.newp`


.. literalinclude:: ../../example/newp.py

:Result:
	.. image:: _static/newp.png
