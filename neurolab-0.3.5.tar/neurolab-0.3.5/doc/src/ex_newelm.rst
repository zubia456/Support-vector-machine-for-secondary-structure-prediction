*************************************
Elman Recurrent network (newelm)
*************************************

Use  :py:func:`neurolab.net.newelm`


.. literalinclude:: ../../example/newelm.py

:Result:
	.. image:: _static/newelm.png