﻿**********************
Competing layer (newc)
**********************

Use  :py:func:`neurolab.net.newc`


.. literalinclude:: ../../example/newc.py

:Result:
	.. image:: _static/classifer.png
